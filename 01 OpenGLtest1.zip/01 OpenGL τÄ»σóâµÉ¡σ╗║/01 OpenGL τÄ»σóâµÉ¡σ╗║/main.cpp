



#include "GLShaderManager.h"
#include "GLTools.h"
#include <glut/glut.h>
#include "GLMatrixStack.h"
#include "GLFrustum.h"
#include "GLGeometryTransform.h"
#include "GLBatch.h"
#include "StopWatch.h"

#include <stdio.h>
#include <math.h>

GLShaderManager shaderManager;
GLMatrixStack   modelViewMatrixStack;//模型视图矩阵堆栈
GLMatrixStack   projectionMatrixStack;//投影视图矩阵堆栈
GLFrustum       viewFrustm;//视景体
GLGeometryTransform transformPipeline;//几何变换管道

GLFrame objectFrame;
GLFrame cameraFrame;



GLBatch floorBatch;
GLTriangleBatch spereBatch;
GLTriangleBatch fiftyBatch;


GLfloat vFloor[] = {0.0f,0.0f,1.0f,1.0f};
GLfloat vSmall[] = {0.0f,1.0f,0.0f,1.0f};
GLfloat vBig[] = {1.0f,0.0f,0.0f,1.0f};

//**4、添加附加随机球
#define NUM_SPHERES 50
GLFrame spheres[NUM_SPHERES];

//窗口大小改变时接受新的宽度和高度，其中0,0代表窗口中视口的左下角坐标，w，h代表像素

void ChangeSize(int w,int h)
{

    glViewport(0,0, w, h);
    viewFrustm.SetPerspective(35.f, float(w)/float(h), 1.f, 100.f);
    
    projectionMatrixStack.LoadMatrix(viewFrustm.GetProjectionMatrix());
    
    transformPipeline.SetMatrixStacks(modelViewMatrixStack, projectionMatrixStack);
    
}

//为程序作一次性的设置

void SetupRC()
{
    glClearColor(0, 0, 0, 1);
    shaderManager.InitializeStockShaders();
    glEnable(GL_DEPTH_TEST);
    
    
    //3. 地板数据(物体坐标系)
    floorBatch.Begin(GL_LINES, 324);
    for(GLfloat x = -20.0; x <= 20.0f; x+= 0.5) {
        floorBatch.Vertex3f(x, -0.55f, 20.0f);
        floorBatch.Vertex3f(x, -0.55f, -20.0f);
        
        floorBatch.Vertex3f(20.0f, -0.55f, x);
        floorBatch.Vertex3f(-20.0f, -0.55f, x);
    }
    floorBatch.End();
    
    gltMakeSphere(spereBatch, 0.4f, 40, 80);
    
    
    gltMakeSphere(fiftyBatch, 0.1f, 13, 26);
    //6. 随机位置放置小球球
    for (int i = 0; i < NUM_SPHERES; i++) {
        
        //y轴不变，X,Z产生随机值
        GLfloat x = ((GLfloat)((rand() % 400) - 200 ) * 0.1f);
        GLfloat z = ((GLfloat)((rand() % 400) - 200 ) * 0.1f);
        
        //在y方向，将球体设置为0.0的位置，这使得它们看起来是飘浮在眼睛的高度
        //对spheres数组中的每一个顶点，设置顶点数据
        spheres[i].SetOrigin(x, 0.0f, z);
    }
}

//开始渲染

void RenderScene(void)
{
    //清除一个或一组特定的缓冲区
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);
    
//    modelViewMatrixStack.PushMatrix();
    
    M3DMatrix44f cameraMartix;
    cameraFrame.GetMatrix(cameraMartix);
    modelViewMatrixStack.PushMatrix(cameraMartix);
    
    shaderManager.UseStockShader(GLT_SHADER_FLAT,transformPipeline.GetModelViewProjectionMatrix(),vFloor);
    floorBatch.Draw();
    
 
    //2. 动画
    static CStopWatch rotTimer;
    float yRot = rotTimer.GetElapsedSeconds()*60.0f;
    
    //5. 设置点光源位置
    M3DVector4f vLightPos = {0,10,5,1};
    
    modelViewMatrixStack.Translate(0, 0, 3);
    modelViewMatrixStack.PushMatrix();
    modelViewMatrixStack.Rotate(yRot, 0, 1, 0);
    shaderManager.UseStockShader(GLT_SHADER_POINT_LIGHT_DIFF,transformPipeline.GetModelViewMatrix(),transformPipeline.GetProjectionMatrix(),vLightPos,vBig);
    spereBatch.Draw();
    modelViewMatrixStack.PopMatrix();
    
    
    for (int i = 0; i<NUM_SPHERES; i++) {
        modelViewMatrixStack.PushMatrix();
        modelViewMatrixStack.MultMatrix(spheres[i]);
        shaderManager.UseStockShader(GLT_SHADER_POINT_LIGHT_DIFF,transformPipeline.GetModelViewMatrix(),transformPipeline.GetProjectionMatrix(),vLightPos,vSmall);
        fiftyBatch.Draw();
        modelViewMatrixStack.PopMatrix();
    }
    
    //9.让一个小球围着大球公转;
    
    modelViewMatrixStack.Rotate(yRot * -2.0f, 0, 1, 0);
    modelViewMatrixStack.Translate(0.8f, 0.0f, 0.0f);
    shaderManager.UseStockShader(GLT_SHADER_POINT_LIGHT_DIFF,transformPipeline.GetModelViewMatrix(),transformPipeline.GetProjectionMatrix(),vLightPos,vSmall);
    fiftyBatch.Draw();
    
    
    
//    modelViewMatrixStack.PopMatrix();
    modelViewMatrixStack.PopMatrix();
    glutSwapBuffers();
    glutPostRedisplay();
}

void SpeacialKeys(int key,int x,int y){
    
    float linear = 0.1f;
    float angular = float(m3dDegToRad(5.0f));
    
    if (key == GLUT_KEY_UP) {
        cameraFrame.MoveForward(linear);
    }
    if (key == GLUT_KEY_DOWN) {
        cameraFrame.MoveForward(-linear);
    }
    
    if (key == GLUT_KEY_LEFT) {
        cameraFrame.RotateWorld(angular, 0, 1, 0);
    }
    if (key == GLUT_KEY_RIGHT) {
        cameraFrame.RotateWorld(-angular, 0, 1, 0);
    }
    
}
int main(int argc,char* argv[])

{
    
    //设置当前工作目录，针对MAC OS X
    
    gltSetWorkingDirectory(argv[0]);
    
    //初始化GLUT库
    
    glutInit(&argc, argv);
    
    /*初始化双缓冲窗口，其中标志GLUT_DOUBLE、GLUT_RGBA、GLUT_DEPTH、GLUT_STENCIL分别指
     
     双缓冲窗口、RGBA颜色模式、深度测试、模板缓冲区*/
    
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGBA|GLUT_DEPTH|GLUT_STENCIL);
    
    //GLUT窗口大小，标题窗口
    
    glutInitWindowSize(800,600);
    
    glutCreateWindow("Triangle");
    
    //注册回调函数
    
    glutReshapeFunc(ChangeSize);
    
    glutDisplayFunc(RenderScene);
    glutSpecialFunc(SpeacialKeys);
    //驱动程序的初始化中没有出现任何问题。
    
    GLenum err = glewInit();
    
    if(GLEW_OK != err) {
        
        fprintf(stderr,"glew error:%s\n",glewGetErrorString(err));
        
        return 1;
        
    }
    
    //调用SetupRC
    
    SetupRC();
    
    glutMainLoop();
    
    return 0;
    
}

